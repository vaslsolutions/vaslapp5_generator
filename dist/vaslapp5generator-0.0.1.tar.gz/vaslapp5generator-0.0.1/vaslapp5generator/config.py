entity_name = 'Brand'
entity_names = 'Brands'
entity_variable = 'brand'
entity_variables = 'brands'
entity_kebab = 'brand'

entity_package = 'brand'

module_name = 'shop'

collection_name = '{module_name}_brands'.format(module_name=module_name)
